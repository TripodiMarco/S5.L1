Automobili={"Ada":"Punto","Ben":"Multipla","Charlie":"Golf","Debbie":"107"}
print(Automobili)
print(Automobili["Debbie"])