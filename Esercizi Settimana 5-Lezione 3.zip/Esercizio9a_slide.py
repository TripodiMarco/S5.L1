def aster(lista:list):
    # dobbiamo creare un loop che per ogni elemento di lista produce un output, 
    # ma prima creiamo una variabile contenente solo il carattere di asterisco
    asterisco="*"
    for numero in lista:
        # dobbiamo fare in modo che la stringa della variabile asterisco venga moltiplicata 
        # tante volte quanto è il valore dell'elemento della lista
        print(asterisco*numero)
numeri=[5,2,3,4]
aster(numeri)