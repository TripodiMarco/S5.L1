def media(lista:list,k:int):
    '''
    Data una lista di valori e dato il valore K, esegue la \n
    media SOLO dei numeri che sono maggiori o uguali a k
    '''
    inferiori=[]                                            # Crea una lista inferiori in cui inserirci i valori inferiori di k
    maggiori=[]                                             # Crea una lista maggiori
    for numero in lista:                                    # Creiamo un loop che permetta di segnarsi i numeri inferiori a k
        if numero<k:                                        # Se il numero è inferiore a k:
            inferiori.append(numero)                        # scrivere dentro alla lista il numero inferiore a k                                
        else:                                               # altrimenti scriverlo dentro a maggiori
            maggiori.append(numero)
    media=sum(maggiori)/len(maggiori)                       # Dopo aver rimosso i numeri inferiori a k dalla lista facciamo la media 
    print(media)                                            # dei numeri rimanenti
    return media
lista=[2,2,2,2,2,4,4,4,4,11,33]
media(lista,3)