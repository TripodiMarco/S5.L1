lista=[654,4,645,646,49,84,654,984,5,64,984]
def num_max():
    if len(lista)<=3:
        print("Lista troppo corta! Aggiungere altri numeri!")
    else:
        print(max(lista))
        indice=lista.index(max(lista))
        del lista[indice]
num_max()
num_max()
num_max()