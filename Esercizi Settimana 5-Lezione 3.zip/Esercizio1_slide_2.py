nome_scuola = "Epicode"
for carattere in nome_scuola:
    print(carattere)