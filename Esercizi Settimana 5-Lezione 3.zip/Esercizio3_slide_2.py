guadagni = [100, 90, 70, 40, 50, 80, 90, 120, 80, 20, 50, 50]
totale=0
for elemento in guadagni:
    totale+=elemento
media=totale/len(guadagni)
print(media)