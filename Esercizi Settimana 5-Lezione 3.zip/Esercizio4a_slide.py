dizionario_auto = {"Ada": "Punto", "Ben": "Multipla", "Charlie": "Golf", "Debbie": "107"}
for elemento in dizionario_auto.values():
    if elemento!="Multipla":
        print(elemento)