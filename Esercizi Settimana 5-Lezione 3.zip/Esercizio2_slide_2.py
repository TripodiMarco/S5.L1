potenza=0
potenza_calcolata=0
numero_massimo=25000
for potenza in range(0,16):
    if numero_massimo<=2**potenza:
        print("Potenza massima raggiunta: 2**", potenza)
    else:
        potenza_calcolata=2**potenza
        print(potenza_calcolata)
