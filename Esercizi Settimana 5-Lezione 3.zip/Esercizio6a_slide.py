lista=[654,4,645,646,49,84,654,984,5,64,984]
def funzione():
    minimo=min(lista)
    massimo=max(lista)
    print("Il numero più basso è", minimo, "mentre il numero più alto è", massimo)
funzione()