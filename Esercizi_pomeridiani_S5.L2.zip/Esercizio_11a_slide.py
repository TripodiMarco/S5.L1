K=int(input("Inserisci un numero: "))
N=0
lista=[]
while N<=10:
    risultato=K**N
    lista.append(risultato)
    N+=1
print(lista)