stringa=str(input("Inserisci una stringa con più di 3 caratteri: "))
if len(stringa)<=2:
    stringa=str(input("Numero di caratteri insufficiente, eseguire nuovamente il codice"))
    print(stringa)
elif len(stringa)<=6:
    output=stringa[0]+'...'+stringa[-1]
    print(output)
else:
    output=stringa[0:3]+'...'+stringa[-3:]
    print(output)