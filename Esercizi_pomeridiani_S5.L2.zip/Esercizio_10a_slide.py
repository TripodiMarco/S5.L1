numero=int(input("Inserisci un numero per ottenere tutti i suoi divisori: "))
divisore=2
while numero>=divisore:       
        if numero%divisore==0:
            risultato=numero/divisore
            numero=risultato
            print(divisore)
        else: divisore+=1