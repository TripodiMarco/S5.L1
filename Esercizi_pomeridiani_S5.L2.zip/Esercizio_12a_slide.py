guadagni = [100, 90, 70, 40, 50, 80, 90, 120, 80, 20, 50, 50]
indice=0
totale3=0
while indice<len(guadagni):
    totale1=totale3
    addizione=guadagni[indice]
    totale3=totale1+addizione
    if indice==(len(guadagni)-1):
        media=totale3/len(guadagni)
        print(media)
    indice+=1