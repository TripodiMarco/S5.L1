studenti = ["Alex", "Bob", "Cindy", "Dan", "Emma", "Faith", "Grace", "Henry"]
corsi = ["Cybersecurity", "Data Analyst", "Backend", "Frontend", "Data Analyst", "Backend"]
corsi.append("Frontend")
corsi.append("Cybersecurity")
if len(studenti)==len(corsi):
    print(corsi)
else: print("Le due liste non hanno la stessa lunghezza")