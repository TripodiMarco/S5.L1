potenza=0
while potenza<=10:
    print(2**potenza)
    potenza+=1