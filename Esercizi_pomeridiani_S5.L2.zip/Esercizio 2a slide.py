nome_scuola = "Epicode"
indice=0
while indice<len(nome_scuola):
    carattere=nome_scuola[indice]
    print(carattere)
    indice+=1