potenza=0
potenza_calcolata=0
numero_massimo=25000
while potenza_calcolata<=numero_massimo:
    potenza_calcolata=2**potenza
    print(potenza_calcolata)
    potenza+=1