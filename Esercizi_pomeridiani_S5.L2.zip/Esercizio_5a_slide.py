potenza=0
num_potenze=int(input("Inserisci il numero di potenze: "))
while potenza <= num_potenze:
    print(2**potenza)
    potenza+=1