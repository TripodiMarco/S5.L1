numero=0
while 0<=numero<=20:
    print(numero)
    numero+=1